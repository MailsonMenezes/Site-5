<?php
/**
 * Configuração do InfinitePay
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Acesse https://infinitepay.io/
 * 2. Crie uma conta de desenvolvedor
 * 3. Obtenha suas credenciais (API Key e Secret)
 * 4. Substitua as variáveis abaixo pelas suas credenciais reais
 * 5. Consulte a documentação: https://docs.infinitepay.io/
 */

// CREDENCIAIS DO INFINITEPAY - SUBSTITUA AQUI
define('INFINITEPAY_API_KEY', 'SEU_API_KEY_AQUI');
define('INFINITEPAY_SECRET', 'SEU_SECRET_AQUI');

// URLs de callback
define('INFINITEPAY_WEBHOOK_URL', 'https://seusite.com/infinitepay_callback.php');
define('INFINITEPAY_SUCCESS_URL', 'https://seusite.com/pagamento-sucesso.php');
define('INFINITEPAY_FAILURE_URL', 'https://seusite.com/pagamento-erro.php');

// Configurações do ambiente
define('INFINITEPAY_SANDBOX', true); // true para testes, false para produção
define('INFINITEPAY_BASE_URL', INFINITEPAY_SANDBOX ? 'https://sandbox-api.infinitepay.io' : 'https://api.infinitepay.io');

/**
 * Função para criar pagamento InfinitePay
 */
function criarPagamentoInfinitePay($pedido_id, $pedido_numero, $total, $metodo_pagamento, $dados_cliente) {
    try {
        $url = INFINITEPAY_BASE_URL . '/v2/transactions';
        
        $data = [
            'amount' => intval($total * 100), // Valor em centavos
            'currency' => 'BRL',
            'reference_id' => $pedido_numero,
            'description' => 'Pedido MX3 Network #' . $pedido_numero,
            'customer' => [
                'name' => $dados_cliente['nome'],
                'email' => $dados_cliente['email'],
                'phone' => preg_replace('/\D/', '', $dados_cliente['telefone']),
                'document' => preg_replace('/\D/', '', $dados_cliente['documento']),
                'address' => [
                    'street' => $dados_cliente['endereco'],
                    'number' => $dados_cliente['numero'],
                    'complement' => $dados_cliente['complemento'] ?? '',
                    'neighborhood' => $dados_cliente['bairro'],
                    'city' => $dados_cliente['cidade'],
                    'state' => $dados_cliente['estado'],
                    'zip_code' => preg_replace('/\D/', '', $dados_cliente['cep'])
                ]
            ],
            'payment_method' => [
                'type' => $metodo_pagamento === 'pix' ? 'pix' : ($metodo_pagamento === 'credit_card' ? 'credit_card' : 'boleto')
            ],
            'notification_url' => INFINITEPAY_WEBHOOK_URL,
            'return_url' => INFINITEPAY_SUCCESS_URL . '?pedido=' . $pedido_numero
        ];
        
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . INFINITEPAY_API_KEY,
            'X-API-Secret: ' . INFINITEPAY_SECRET
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200 || $http_code === 201) {
            $result = json_decode($response, true);
            
            if (isset($result['payment_url'])) {
                return $result['payment_url'];
            } elseif (isset($result['pix_qr_code'])) {
                // Para PIX, você pode retornar o QR Code ou uma página personalizada
                return INFINITEPAY_SUCCESS_URL . '?pix=' . urlencode($result['pix_qr_code']) . '&pedido=' . $pedido_numero;
            }
        }
        
        error_log("Erro InfinitePay HTTP $http_code: $response");
        return null;
        
    } catch (Exception $e) {
        error_log("Erro no InfinitePay: " . $e->getMessage());
        return null;
    }
}

/**
 * Função para processar webhook do InfinitePay
 */
function processarWebhookInfinitePay($webhook_data) {
    try {
        // Verificar assinatura do webhook (recomendado)
        $signature = $_SERVER['HTTP_X_INFINITEPAY_SIGNATURE'] ?? '';
        $expected_signature = hash_hmac('sha256', json_encode($webhook_data), INFINITEPAY_SECRET);
        
        if (!hash_equals($signature, $expected_signature)) {
            error_log("Assinatura inválida do webhook InfinitePay");
            return false;
        }
        
        $status_map = [
            'pending' => 'pendente',
            'processing' => 'pendente',
            'paid' => 'pago',
            'approved' => 'pago',
            'cancelled' => 'cancelado',
            'failed' => 'cancelado',
            'refunded' => 'cancelado'
        ];
        
        $novo_status = $status_map[$webhook_data['status']] ?? 'pendente';
        $reference_id = $webhook_data['reference_id'];
        $transaction_id = $webhook_data['id'];
        
        // Atualizar status do pedido no banco
        global $pdo;
        $sql = "UPDATE pedidos SET status = ?, transaction_id = ? WHERE numero_pedido = ?";
        executeQuery($sql, [$novo_status, $transaction_id, $reference_id]);
        
        // Log da transação
        $sql_log = "INSERT INTO pagamento_logs (pedido_id, plataforma, transaction_id, status, valor, dados_retorno) 
                    SELECT id, 'infinitepay', ?, ?, ?, ? FROM pedidos WHERE numero_pedido = ?";
        executeQuery($sql_log, [
            $transaction_id,
            $webhook_data['status'],
            $webhook_data['amount'] / 100,
            json_encode($webhook_data),
            $reference_id
        ]);
        
        return true;
        
    } catch (Exception $e) {
        error_log("Erro ao processar webhook InfinitePay: " . $e->getMessage());
        return false;
    }
}

/**
 * Função para consultar status de transação
 */
function consultarTransacaoInfinitePay($transaction_id) {
    try {
        $url = INFINITEPAY_BASE_URL . '/v2/transactions/' . $transaction_id;
        
        $headers = [
            'Authorization: Bearer ' . INFINITEPAY_API_KEY,
            'X-API-Secret: ' . INFINITEPAY_SECRET
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            return json_decode($response, true);
        }
        
        return null;
        
    } catch (Exception $e) {
        error_log("Erro ao consultar transação InfinitePay: " . $e->getMessage());
        return null;
    }
}
?>

