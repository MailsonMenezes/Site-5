# 📋 INSTRUÇÕES DE CONFIGURAÇÃO - MX3 NETWORK

## 🚀 ARQUIVOS PARA UPLOAD NO CPANEL

Faça upload dos seguintes arquivos para o diretório `public_html` do seu cPanel:

### ✅ Arquivos Essenciais:
- `index.html` - Página principal (mantém todos os estilos visuais)
- `carrinho.php` - Página do carrinho de compras
- `finalizar-compra.php` - Página de checkout
- `processa_compra.php` - Processamento de pedidos
- `minha-conta.php` - Área do cliente
- `db_connect.php` - Conexão com banco de dados
- `.htaccess` - Configurações do servidor
- `database.sql` - Script de criação das tabelas

### 🔧 Arquivos de Configuração de Pagamento:
- `mercadopago_config.php` - Configuração Mercado Pago
- `pagseguro_config.php` - Configuração PagSeguro  
- `paypal_config.php` - Configuração PayPal
- `infinitepay_config.php` - Configuração InfinitePay

---

## 🗄️ CONFIGURAÇÃO DO BANCO DE DADOS

### 1. Criar Banco MySQL no cPanel:
1. Acesse **MySQL Databases** no cPanel
2. Crie um novo banco de dados (ex: `mx3network_db`)
3. Crie um usuário MySQL (ex: `mx3network_user`)
4. Adicione o usuário ao banco com **ALL PRIVILEGES**

### 2. Executar Script SQL:
1. Acesse **phpMyAdmin** no cPanel
2. Selecione seu banco de dados
3. Vá na aba **SQL**
4. Cole o conteúdo do arquivo `database.sql`
5. Clique em **Executar**

### 3. Configurar Conexão:
Edite o arquivo `db_connect.php` e substitua:

```php
$db_host = 'localhost';                    // Geralmente localhost
$db_name = 'SEU_BANCO_DE_DADOS';          // Nome do banco criado
$db_user = 'SEU_USUARIO_MYSQL';           // Usuário MySQL
$db_pass = 'SUA_SENHA_MYSQL';             // Senha MySQL
```

---

## 💳 CONFIGURAÇÃO DOS PAGAMENTOS

### 🔵 MERCADO PAGO

1. **Criar Conta:**
   - Acesse: https://www.mercadopago.com.br/developers/
   - Crie uma aplicação

2. **Obter Credenciais:**
   - Access Token (Produção e Sandbox)
   - Public Key (Produção e Sandbox)

3. **Configurar:**
   Edite `mercadopago_config.php`:
   ```php
   define('MERCADOPAGO_ACCESS_TOKEN', 'SEU_ACCESS_TOKEN_AQUI');
   define('MERCADOPAGO_PUBLIC_KEY', 'SEU_PUBLIC_KEY_AQUI');
   ```

4. **Instalar SDK:**
   ```bash
   composer require mercadopago/dx-php
   ```

5. **Descomente o código** nas funções do arquivo após instalar o SDK

### 🟡 PAGSEGURO

1. **Criar Conta:**
   - Acesse: https://dev.pagseguro.uol.com.br/
   - Crie conta de desenvolvedor

2. **Obter Credenciais:**
   - Token de Produção/Sandbox
   - App ID e App Key

3. **Configurar:**
   Edite `pagseguro_config.php`:
   ```php
   define('PAGSEGURO_TOKEN', 'SEU_TOKEN_AQUI');
   define('PAGSEGURO_APP_ID', 'SEU_APP_ID_AQUI');
   define('PAGSEGURO_APP_KEY', 'SEU_APP_KEY_AQUI');
   ```

4. **Instalar SDK:**
   ```bash
   composer require pagseguro/pagseguro-php-sdk
   ```

### 🔴 PAYPAL

1. **Criar Conta:**
   - Acesse: https://developer.paypal.com/
   - Crie uma aplicação

2. **Obter Credenciais:**
   - Client ID
   - Client Secret

3. **Configurar:**
   Edite `paypal_config.php`:
   ```php
   define('PAYPAL_CLIENT_ID', 'SEU_CLIENT_ID_AQUI');
   define('PAYPAL_CLIENT_SECRET', 'SEU_CLIENT_SECRET_AQUI');
   ```

4. **Instalar SDK:**
   ```bash
   composer require paypal/rest-api-sdk-php
   ```

### 🟢 INFINITEPAY

1. **Criar Conta:**
   - Acesse: https://infinitepay.io/
   - Crie conta de desenvolvedor

2. **Obter Credenciais:**
   - API Key
   - Secret Key

3. **Configurar:**
   Edite `infinitepay_config.php`:
   ```php
   define('INFINITEPAY_API_KEY', 'SEU_API_KEY_AQUI');
   define('INFINITEPAY_SECRET', 'SEU_SECRET_AQUI');
   ```

4. **Não precisa de SDK** - Usa cURL nativo do PHP

---

## 🔧 CONFIGURAÇÕES ADICIONAIS

### 1. URLs de Callback:
Substitua `https://seusite.com` pelas URLs reais do seu site em todos os arquivos de configuração.

### 2. Ambiente de Produção:
Altere as configurações de sandbox para `false` quando for para produção:
```php
define('MERCADOPAGO_SANDBOX', false);
define('PAGSEGURO_SANDBOX', false);
define('PAYPAL_SANDBOX', false);
define('INFINITEPAY_SANDBOX', false);
```

### 3. Permissões de Arquivos:
- Arquivos PHP: 644
- Diretórios: 755
- .htaccess: 644

### 4. SSL/HTTPS:
- **OBRIGATÓRIO** para pagamentos
- Configure certificado SSL no cPanel
- Descomente as linhas de redirecionamento HTTPS no `.htaccess`

---

## 📧 CONFIGURAÇÃO DE E-MAIL

Para envio de e-mails de confirmação, configure SMTP no cPanel ou use a função `mail()` do PHP.

Exemplo de configuração SMTP:
```php
// Adicionar ao final do db_connect.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

function enviarEmail($destinatario, $assunto, $mensagem) {
    $mail = new PHPMailer(true);
    
    $mail->isSMTP();
    $mail->Host = 'mail.seudominio.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'noreply@seudominio.com';
    $mail->Password = 'sua_senha_email';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    
    $mail->setFrom('noreply@seudominio.com', 'MX3 Network');
    $mail->addAddress($destinatario);
    
    $mail->isHTML(true);
    $mail->Subject = $assunto;
    $mail->Body = $mensagem;
    
    return $mail->send();
}
```

---

## 🧪 TESTE DO SISTEMA

### 1. Teste Básico:
1. Acesse `https://seusite.com`
2. Adicione produtos ao carrinho
3. Vá para o carrinho
4. Finalize a compra
5. Teste os pagamentos em modo sandbox

### 2. Teste de Banco:
1. Verifique se as tabelas foram criadas
2. Confirme se os pedidos estão sendo salvos
3. Teste a área "Minha Conta"

### 3. Logs de Erro:
- Verifique logs do PHP no cPanel
- Monitore logs de pagamento
- Teste notificações/webhooks

---

## 🆘 SUPORTE E TROUBLESHOOTING

### Problemas Comuns:

1. **Erro de Conexão com Banco:**
   - Verifique credenciais em `db_connect.php`
   - Confirme se o banco foi criado corretamente

2. **Pagamentos não Funcionam:**
   - Verifique se as credenciais estão corretas
   - Confirme se os SDKs foram instalados
   - Descomente o código nas funções de pagamento

3. **Erro 500:**
   - Verifique logs de erro do PHP
   - Confirme permissões dos arquivos
   - Verifique sintaxe do PHP

4. **Carrinho não Funciona:**
   - Verifique se JavaScript está habilitado
   - Confirme se localStorage está funcionando
   - Teste em diferentes navegadores

### Contatos de Suporte das Plataformas:
- **Mercado Pago:** https://www.mercadopago.com.br/developers/pt/support
- **PagSeguro:** https://dev.pagseguro.uol.com.br/docs/suporte
- **PayPal:** https://developer.paypal.com/support/
- **InfinitePay:** https://infinitepay.io/suporte

---

## ✅ CHECKLIST FINAL

- [ ] Banco de dados criado e configurado
- [ ] Arquivo `db_connect.php` configurado
- [ ] Pelo menos uma plataforma de pagamento configurada
- [ ] SSL/HTTPS ativo
- [ ] Teste de compra realizado
- [ ] E-mails de confirmação funcionando
- [ ] Logs de erro verificados
- [ ] Backup dos arquivos realizado

---

## 🔒 SEGURANÇA

1. **Nunca commite credenciais** em repositórios públicos
2. **Use HTTPS** sempre para pagamentos
3. **Mantenha backups** regulares do banco
4. **Monitore logs** de transações
5. **Atualize** regularmente os SDKs
6. **Valide** sempre dados de entrada
7. **Use prepared statements** (já implementado)

---

**🎉 Parabéns! Seu e-commerce MX3 Network está pronto para funcionar!**

Para dúvidas específicas, consulte a documentação oficial de cada plataforma de pagamento ou entre em contato com o suporte técnico do seu provedor de hospedagem.

