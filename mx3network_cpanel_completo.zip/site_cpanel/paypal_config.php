<?php
/**
 * Configuração do PayPal
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Acesse https://developer.paypal.com/
 * 2. Crie uma aplicação
 * 3. Obtenha suas credenciais (Client ID e Client Secret)
 * 4. Substitua as variáveis abaixo pelas suas credenciais reais
 * 5. Instale o SDK do PayPal via Composer: composer require paypal/rest-api-sdk-php
 */

// CREDENCIAIS DO PAYPAL - SUBSTITUA AQUI
define('PAYPAL_CLIENT_ID', 'SEU_CLIENT_ID_AQUI');
define('PAYPAL_CLIENT_SECRET', 'SEU_CLIENT_SECRET_AQUI');

// URLs de callback
define('PAYPAL_SUCCESS_URL', 'https://seusite.com/paypal-sucesso.php');
define('PAYPAL_CANCEL_URL', 'https://seusite.com/paypal-cancelado.php');
define('PAYPAL_WEBHOOK_URL', 'https://seusite.com/paypal_callback.php');

// Configurações do ambiente
define('PAYPAL_SANDBOX', true); // true para testes, false para produção

/**
 * Função para criar pagamento PayPal
 */
function criarPagamentoPayPal($pedido_id, $pedido_numero, $total, $metodo_pagamento, $dados_cliente) {
    try {
        // Incluir SDK do PayPal
        // require_once 'vendor/autoload.php';
        
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        $apiContext = new \PayPal\Rest\ApiContext(
            new \PayPal\Auth\OAuthTokenCredential(
                PAYPAL_CLIENT_ID,
                PAYPAL_CLIENT_SECRET
            )
        );
        
        $apiContext->setConfig([
            'mode' => PAYPAL_SANDBOX ? 'sandbox' : 'live',
            'log.LogEnabled' => true,
            'log.FileName' => '/tmp/PayPal.log',
            'log.LogLevel' => 'DEBUG'
        ]);
        
        $payer = new \PayPal\Api\Payer();
        $payer->setPaymentMethod('paypal');
        
        $item = new \PayPal\Api\Item();
        $item->setName('Pedido MX3 Network #' . $pedido_numero)
             ->setCurrency('BRL')
             ->setQuantity(1)
             ->setPrice($total);
        
        $itemList = new \PayPal\Api\ItemList();
        $itemList->setItems([$item]);
        
        $amount = new \PayPal\Api\Amount();
        $amount->setCurrency('BRL')
               ->setTotal($total);
        
        $transaction = new \PayPal\Api\Transaction();
        $transaction->setAmount($amount)
                   ->setItemList($itemList)
                   ->setDescription('Pedido MX3 Network #' . $pedido_numero)
                   ->setInvoiceNumber($pedido_numero);
        
        $redirectUrls = new \PayPal\Api\RedirectUrls();
        $redirectUrls->setReturnUrl(PAYPAL_SUCCESS_URL . '?pedido=' . $pedido_numero)
                    ->setCancelUrl(PAYPAL_CANCEL_URL . '?pedido=' . $pedido_numero);
        
        $payment = new \PayPal\Api\Payment();
        $payment->setIntent('sale')
               ->setPayer($payer)
               ->setRedirectUrls($redirectUrls)
               ->setTransactions([$transaction]);
        
        $payment->create($apiContext);
        
        return $payment->getApprovalLink();
        */
        
        // REMOVER ESTA LINHA QUANDO CONFIGURAR O SDK:
        return null;
        
    } catch (Exception $e) {
        error_log("Erro no PayPal: " . $e->getMessage());
        return null;
    }
}

/**
 * Função para executar pagamento PayPal após aprovação
 */
function executarPagamentoPayPal($payment_id, $payer_id) {
    try {
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        $apiContext = new \PayPal\Rest\ApiContext(
            new \PayPal\Auth\OAuthTokenCredential(
                PAYPAL_CLIENT_ID,
                PAYPAL_CLIENT_SECRET
            )
        );
        
        $apiContext->setConfig([
            'mode' => PAYPAL_SANDBOX ? 'sandbox' : 'live'
        ]);
        
        $payment = \PayPal\Api\Payment::get($payment_id, $apiContext);
        
        $execution = new \PayPal\Api\PaymentExecution();
        $execution->setPayerId($payer_id);
        
        $result = $payment->execute($execution, $apiContext);
        
        if ($result->getState() === 'approved') {
            // Atualizar status do pedido no banco
            $invoice_number = $result->getTransactions()[0]->getInvoiceNumber();
            
            global $pdo;
            $sql = "UPDATE pedidos SET status = 'pago', transaction_id = ? WHERE numero_pedido = ?";
            executeQuery($sql, [$payment_id, $invoice_number]);
            
            return true;
        }
        */
        
        return false;
        
    } catch (Exception $e) {
        error_log("Erro ao executar pagamento PayPal: " . $e->getMessage());
        return false;
    }
}

/**
 * Função para processar webhook do PayPal
 */
function processarWebhookPayPal($webhook_data) {
    try {
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        if ($webhook_data['event_type'] === 'PAYMENT.SALE.COMPLETED') {
            $sale = $webhook_data['resource'];
            $invoice_number = $sale['invoice_number'];
            
            global $pdo;
            $sql = "UPDATE pedidos SET status = 'pago', transaction_id = ? WHERE numero_pedido = ?";
            executeQuery($sql, [$sale['id'], $invoice_number]);
            
            return true;
        }
        */
        
        return false;
        
    } catch (Exception $e) {
        error_log("Erro ao processar webhook PayPal: " . $e->getMessage());
        return false;
    }
}
?>

