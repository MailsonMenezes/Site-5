<?php
session_start();
require_once "db_connect.php";

// Simulação de login para teste - REMOVER EM PRODUÇÃO
if (!isset($_SESSION["loggedin"])) {
    $_SESSION["loggedin"] = true;
    $_SESSION["id"] = 1;
    $_SESSION["nome"] = "Usuário Teste";
    $_SESSION["email"] = "teste@exemplo.com";
    $_SESSION["telefone"] = "(83) 99999-9999";
}

// Buscar pedidos do usuário
$pedidos = [];
if (isset($_SESSION["id"])) {
    $sql = "SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY data_criacao DESC";
    $pedidos = fetchAll($sql, [$_SESSION["id"]]) ?: [];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Minha Conta - MX3 Network</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <style>
        :root {
            --color-black: hsl(210, 15%, 5%); --color-gray-900: hsl(210, 15%, 8%); --color-gray-800: hsl(210, 15%, 12%); --color-gray-700: hsl(210, 15%, 16%); --color-gray-600: hsl(210, 15%, 24%); --color-gray-500: hsl(210, 15%, 32%); --color-gray-400: hsl(210, 15%, 48%); --color-gray-300: hsl(210, 15%, 64%); --color-gray-200: hsl(210, 15%, 80%); --color-gray-100: hsl(210, 15%, 96%); --color-white: hsl(0, 0%, 100%); --color-blue-700: hsl(196, 100%, 30%); --color-blue-600: hsl(196, 100%, 40%); --color-blue-500: hsl(196, 100%, 50%); --color-blue-400: hsl(196, 100%, 60%); --color-blue-300: hsl(196, 100%, 70%); --color-primary: var(--color-blue-500); --color-primary-hover: var(--color-blue-400); --color-primary-dark: var(--color-blue-600); --bg-primary: var(--color-gray-900); --bg-secondary: var(--color-gray-800); --bg-tertiary: var(--color-gray-700); --bg-card: rgba(255, 255, 255, 0.05); --bg-card-hover: rgba(255, 255, 255, 0.08); --text-primary: var(--color-white); --text-secondary: var(--color-gray-200); --text-muted: var(--color-gray-400); --space-xs: 0.25rem; --space-sm: 0.5rem; --space-md: 1rem; --space-lg: 1.5rem; --space-xl: 2rem; --space-2xl: 3rem; --space-3xl: 4rem; --space-4xl: 6rem; --radius-sm: 0.375rem; --radius-md: 0.5rem; --radius-lg: 0.75rem; --radius-xl: 1rem; --radius-2xl: 1.5rem; --shadow-glow: 0 0 30px rgba(0, 178, 255, 0.4); --font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; --font-size-sm: 0.875rem; --font-size-base: 1rem; --font-size-lg: 1.125rem; --font-size-xl: 1.25rem; --font-size-2xl: 1.5rem; --font-size-3xl: 1.875rem; --z-header: 50; --transition-fast: 150ms ease-in-out; --transition-normal: 300ms ease-in-out;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { font-family: var(--font-family); font-size: var(--font-size-base); line-height: 1.6; color: var(--text-primary); background-color: var(--bg-primary); }
        img { max-width: 100%; height: auto; display: block; }
        button { font-family: inherit; border: none; background: none; cursor: pointer; }
        a { color: inherit; text-decoration: none; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 var(--space-lg); }
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: var(--space-sm); padding: var(--space-md) var(--space-xl); font-weight: 600; border-radius: var(--radius-lg); transition: all var(--transition-fast); text-align: center; border: 2px solid transparent; }
        .btn-primary { background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%); color: var(--text-primary); box-shadow: var(--shadow-glow); }
        .btn-primary:hover { transform: translateY(-3px); }
        .btn-outline { background: transparent; color: var(--color-primary); border: 2px solid var(--color-primary); }
        .btn-outline:hover { background: var(--color-primary); color: var(--text-primary); }
        .header { position: sticky; top: 0; left: 0; right: 0; background: rgba(16, 24, 40, 0.95); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255, 255, 255, 0.1); z-index: var(--z-header); }
        .header-container { display: flex; align-items: center; justify-content: space-between; padding: var(--space-lg) 0; min-height: 80px; }
        .logo { display: flex; align-items: center; gap: var(--space-xs); font-size: var(--font-size-2xl); font-weight: 800; }
        .logo-text { color: var(--color-primary); }
        .logo-subtext { color: var(--text-secondary); font-weight: 500; font-size: var(--font-size-base); }
        .header-actions { display: flex; align-items: center; gap: var(--space-lg); }
        .footer { background: var(--color-black); padding: var(--space-4xl) 0 var(--space-xl); border-top: 1px solid rgba(255, 255, 255, 0.1); margin-top: var(--space-4xl); }
        .footer-bottom { border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: var(--space-lg); text-align: center; color: var(--text-muted); font-size: var(--font-size-sm); }
        
        .account-section { padding: var(--space-4xl) 0; }
        .account-grid { display: grid; grid-template-columns: 300px 1fr; gap: var(--space-3xl); align-items: flex-start; }
        .account-sidebar { background: var(--bg-secondary); border-radius: var(--radius-xl); padding: var(--space-2xl); position: sticky; top: 100px; }
        .account-nav { list-style: none; }
        .account-nav li { margin-bottom: var(--space-md); }
        .account-nav a { display: flex; align-items: center; gap: var(--space-md); padding: var(--space-md); border-radius: var(--radius-lg); color: var(--text-secondary); transition: all var(--transition-fast); }
        .account-nav a:hover, .account-nav a.active { background: var(--color-primary); color: var(--text-primary); }
        .account-content { background: var(--bg-secondary); border-radius: var(--radius-xl); padding: var(--space-2xl); }
        .account-content h2 { font-size: var(--font-size-2xl); font-weight: 700; margin-bottom: var(--space-xl); color: var(--text-primary); }
        .user-info { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl); }
        .info-card { background: var(--color-gray-700); border-radius: var(--radius-lg); padding: var(--space-lg); }
        .info-card h3 { font-size: var(--font-size-lg); font-weight: 600; margin-bottom: var(--space-sm); color: var(--text-primary); }
        .info-card p { color: var(--text-secondary); }
        .orders-table { width: 100%; border-collapse: collapse; margin-top: var(--space-lg); }
        .orders-table th, .orders-table td { text-align: left; padding: var(--space-lg) var(--space-md); border-bottom: 1px solid var(--color-gray-700); }
        .orders-table th { color: var(--text-secondary); font-weight: 500; }
        .status-badge { padding: var(--space-xs) var(--space-sm); border-radius: var(--radius-sm); font-size: var(--font-size-sm); font-weight: 600; }
        .status-pendente { background: #fbbf24; color: #92400e; }
        .status-pago { background: #10b981; color: #065f46; }
        .status-cancelado { background: #ef4444; color: #991b1b; }
        
        @media (max-width: 768px) {
            .account-grid { grid-template-columns: 1fr; }
            .account-sidebar { position: static; }
            .user-info { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-container">
                <a href="index.html" class="logo">
                    <span class="logo-text">MX3</span>
                    <span class="logo-subtext">NETWORK</span>
                </a>
                
                <div class="header-actions">
                    <a href="carrinho.php" class="btn btn-outline">
                        <i class="fas fa-shopping-cart"></i>
                        Carrinho
                    </a>
                    <a href="logout.php" class="btn btn-primary">
                        <i class="fas fa-sign-out-alt"></i>
                        Sair
                    </a>
                </div>
            </div>
        </div>
    </header>

    <section class="account-section">
        <div class="container">
            <h1 style="margin-bottom: var(--space-2xl); font-size: 2.5rem; text-align: center;">Minha Conta</h1>
            
            <div class="account-grid">
                <div class="account-sidebar">
                    <div style="text-align: center; margin-bottom: var(--space-xl);">
                        <div style="width: 80px; height: 80px; background: var(--color-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto var(--space-md); font-size: var(--font-size-2xl);">
                            <i class="fas fa-user"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($_SESSION['nome']); ?></h3>
                        <p style="color: var(--text-muted); font-size: var(--font-size-sm);"><?php echo htmlspecialchars($_SESSION['email']); ?></p>
                    </div>
                    
                    <ul class="account-nav">
                        <li><a href="#" class="nav-link active" data-section="profile"><i class="fas fa-user"></i> Meu Perfil</a></li>
                        <li><a href="#" class="nav-link" data-section="orders"><i class="fas fa-shopping-bag"></i> Meus Pedidos</a></li>
                        <li><a href="#" class="nav-link" data-section="addresses"><i class="fas fa-map-marker-alt"></i> Endereços</a></li>
                        <li><a href="#" class="nav-link" data-section="security"><i class="fas fa-lock"></i> Segurança</a></li>
                    </ul>
                </div>
                
                <div class="account-content">
                    <div id="profile-section" class="content-section">
                        <h2><i class="fas fa-user"></i> Meu Perfil</h2>
                        
                        <div class="user-info">
                            <div class="info-card">
                                <h3>Informações Pessoais</h3>
                                <p><strong>Nome:</strong> <?php echo htmlspecialchars($_SESSION['nome']); ?></p>
                                <p><strong>E-mail:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
                                <p><strong>Telefone:</strong> <?php echo htmlspecialchars($_SESSION['telefone']); ?></p>
                            </div>
                            
                            <div class="info-card">
                                <h3>Estatísticas</h3>
                                <p><strong>Pedidos realizados:</strong> <?php echo count($pedidos); ?></p>
                                <p><strong>Membro desde:</strong> Janeiro 2025</p>
                                <p><strong>Status:</strong> Cliente Ativo</p>
                            </div>
                        </div>
                        
                        <button class="btn btn-primary">
                            <i class="fas fa-edit"></i>
                            Editar Perfil
                        </button>
                    </div>
                    
                    <div id="orders-section" class="content-section" style="display: none;">
                        <h2><i class="fas fa-shopping-bag"></i> Meus Pedidos</h2>
                        
                        <?php if (empty($pedidos)): ?>
                            <div style="text-align: center; padding: var(--space-4xl); color: var(--text-secondary);">
                                <i class="fas fa-shopping-bag" style="font-size: 4rem; margin-bottom: var(--space-lg); color: var(--text-muted);"></i>
                                <h3>Nenhum pedido encontrado</h3>
                                <p>Você ainda não realizou nenhum pedido.</p>
                                <a href="index.html" class="btn btn-primary" style="margin-top: var(--space-lg);">
                                    Começar a Comprar
                                </a>
                            </div>
                        <?php else: ?>
                            <table class="orders-table">
                                <thead>
                                    <tr>
                                        <th>Pedido</th>
                                        <th>Data</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pedidos as $pedido): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($pedido['numero_pedido']); ?></strong></td>
                                        <td><?php echo date('d/m/Y', strtotime($pedido['data_criacao'])); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $pedido['status']; ?>">
                                                <?php echo ucfirst($pedido['status']); ?>
                                            </span>
                                        </td>
                                        <td>R$ <?php echo number_format($pedido['total'], 2, ',', '.'); ?></td>
                                        <td>
                                            <button class="btn btn-outline" style="padding: var(--space-xs) var(--space-sm); font-size: var(--font-size-sm);">
                                                Ver Detalhes
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                    
                    <div id="addresses-section" class="content-section" style="display: none;">
                        <h2><i class="fas fa-map-marker-alt"></i> Meus Endereços</h2>
                        
                        <div style="text-align: center; padding: var(--space-4xl); color: var(--text-secondary);">
                            <i class="fas fa-map-marker-alt" style="font-size: 4rem; margin-bottom: var(--space-lg); color: var(--text-muted);"></i>
                            <h3>Nenhum endereço cadastrado</h3>
                            <p>Adicione endereços para facilitar suas compras futuras.</p>
                            <button class="btn btn-primary" style="margin-top: var(--space-lg);">
                                <i class="fas fa-plus"></i>
                                Adicionar Endereço
                            </button>
                        </div>
                    </div>
                    
                    <div id="security-section" class="content-section" style="display: none;">
                        <h2><i class="fas fa-lock"></i> Segurança</h2>
                        
                        <div class="user-info">
                            <div class="info-card">
                                <h3>Alterar Senha</h3>
                                <p>Mantenha sua conta segura alterando sua senha regularmente.</p>
                                <button class="btn btn-primary" style="margin-top: var(--space-md);">
                                    Alterar Senha
                                </button>
                            </div>
                            
                            <div class="info-card">
                                <h3>Autenticação em Duas Etapas</h3>
                                <p>Adicione uma camada extra de segurança à sua conta.</p>
                                <button class="btn btn-outline" style="margin-top: var(--space-md);">
                                    Configurar 2FA
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; 2025 MX3 Network. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navLinks = document.querySelectorAll('.nav-link');
            const contentSections = document.querySelectorAll('.content-section');

            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Remove active class from all links
                    navLinks.forEach(l => l.classList.remove('active'));
                    
                    // Add active class to clicked link
                    this.classList.add('active');
                    
                    // Hide all content sections
                    contentSections.forEach(section => section.style.display = 'none');
                    
                    // Show target section
                    const targetSection = this.getAttribute('data-section') + '-section';
                    document.getElementById(targetSection).style.display = 'block';
                });
            });
        });
    </script>
</body>
</html>

