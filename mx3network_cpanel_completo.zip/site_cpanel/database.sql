-- Script SQL para criação das tabelas necessárias
-- Execute este script no phpMyAdmin ou interface MySQL do cPanel

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `telefone` varchar(20) DEFAULT NULL,
  `senha` varchar(255) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_pedido` varchar(50) NOT NULL UNIQUE,
  `usuario_id` int(11) DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `frete` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pendente','pago','cancelado','enviado','entregue') NOT NULL DEFAULT 'pendente',
  `metodo_pagamento` enum('pix','credit_card','boleto','debit_card') NOT NULL,
  `plataforma_pagamento` enum('mercadopago','pagseguro','paypal','infinitepay') NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_url` text DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_numero_pedido` (`numero_pedido`),
  KEY `idx_usuario_id` (`usuario_id`),
  KEY `idx_status` (`status`),
  KEY `idx_data_criacao` (`data_criacao`),
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de itens do pedido
CREATE TABLE IF NOT EXISTS `pedido_itens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `produto_id` varchar(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pedido_id` (`pedido_id`),
  KEY `idx_produto_id` (`produto_id`),
  FOREIGN KEY (`pedido_id`) REFERENCES `pedidos`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de produtos (opcional - para catálogo completo)
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` varchar(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_ativo` (`ativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de endereços dos usuários
CREATE TABLE IF NOT EXISTS `enderecos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `padrao` tinyint(1) NOT NULL DEFAULT 0,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_id` (`usuario_id`),
  KEY `idx_padrao` (`padrao`),
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de logs de pagamento
CREATE TABLE IF NOT EXISTS `pagamento_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `plataforma` varchar(50) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `dados_retorno` text DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pedido_id` (`pedido_id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`pedido_id`) REFERENCES `pedidos`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir produtos de exemplo
INSERT INTO `produtos` (`id`, `nome`, `descricao`, `preco`, `categoria`, `imagem`, `estoque`) VALUES
('olt-x7', 'OLT HUAWEI MA5800-X7', 'Huawei SmartAX MA5800 X7 NG OLT, 19 polegadas, com 6U de altura, 7 slots.', 16945.00, 'OLT', 'https://mx3network.com/imagens/TERM.CHASSI%20%20HUAWEI-MA5800-X7-6U.jpg', 10),
('olt-x2', 'TERMINAL OLT HUAWEI 2U MINI MA5800 X2', 'Chassi OLT compacto da Huawei, ideal para cenários de menor densidade.', 12350.60, 'OLT', 'https://mx3network.com/imagens/TERMINAL%20OLT%20HUAWEI%202U%20MINI%20MA5800%20X2%201OG%201*MPSG%202*PISB%20DC.JPEG', 15),
('switch-s6720s', 'Switch Huawei S6720s 24-Portas SFP+', 'Switch de alto desempenho com 24 portas SFP+ para redes corporativas.', 24800.00, 'Switch', 'https://mx3network.com/imagens/Switch%20Huawei%20S6730-H24X6C%20CloudEngine%20OLT%20SFP%2024%20Portas.jpeg', 8),
('sfp-kit-10g', 'Kit Transceptor Óptico SFP+ 10G', 'Transceptor óptico SFP+ para conexões de 10 Gigabit em fibra óptica.', 1500.00, 'Transceptor', 'https://mx3network.com/imagens/Transceiver%20teste.jpeg', 50);

-- Inserir usuário de teste (senha: 123456)
INSERT INTO `usuarios` (`nome`, `email`, `telefone`, `senha`) VALUES
('Usuário Teste', 'teste@exemplo.com', '(83) 99999-9999', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Índices adicionais para performance
CREATE INDEX idx_pedidos_data_status ON pedidos(data_criacao, status);
CREATE INDEX idx_produtos_categoria_ativo ON produtos(categoria, ativo);
CREATE INDEX idx_usuarios_email_ativo ON usuarios(email);

-- Comentários das tabelas
ALTER TABLE `usuarios` COMMENT = 'Tabela de usuários do sistema';
ALTER TABLE `pedidos` COMMENT = 'Tabela de pedidos realizados';
ALTER TABLE `pedido_itens` COMMENT = 'Itens de cada pedido';
ALTER TABLE `produtos` COMMENT = 'Catálogo de produtos';
ALTER TABLE `enderecos` COMMENT = 'Endereços dos usuários';
ALTER TABLE `pagamento_logs` COMMENT = 'Logs de transações de pagamento';

