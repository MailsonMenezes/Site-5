<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Meu Carrinho - MX3 Network</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <style>
        :root {
            --color-black: hsl(210, 15%, 5%); --color-gray-900: hsl(210, 15%, 8%); --color-gray-800: hsl(210, 15%, 12%); --color-gray-700: hsl(210, 15%, 16%); --color-gray-600: hsl(210, 15%, 24%); --color-gray-500: hsl(210, 15%, 32%); --color-gray-400: hsl(210, 15%, 48%); --color-gray-300: hsl(210, 15%, 64%); --color-gray-200: hsl(210, 15%, 80%); --color-gray-100: hsl(210, 15%, 96%); --color-white: hsl(0, 0%, 100%); --color-blue-700: hsl(196, 100%, 30%); --color-blue-600: hsl(196, 100%, 40%); --color-blue-500: hsl(196, 100%, 50%); --color-blue-400: hsl(196, 100%, 60%); --color-blue-300: hsl(196, 100%, 70%); --color-primary: var(--color-blue-500); --color-primary-hover: var(--color-blue-400); --color-primary-dark: var(--color-blue-600); --bg-primary: var(--color-gray-900); --bg-secondary: var(--color-gray-800); --bg-tertiary: var(--color-gray-700); --bg-card: rgba(255, 255, 255, 0.05); --bg-card-hover: rgba(255, 255, 255, 0.08); --text-primary: var(--color-white); --text-secondary: var(--color-gray-200); --text-muted: var(--color-gray-400); --space-xs: 0.25rem; --space-sm: 0.5rem; --space-md: 1rem; --space-lg: 1.5rem; --space-xl: 2rem; --space-2xl: 3rem; --space-3xl: 4rem; --space-4xl: 6rem; --radius-sm: 0.375rem; --radius-md: 0.5rem; --radius-lg: 0.75rem; --radius-xl: 1rem; --radius-2xl: 1.5rem; --shadow-glow: 0 0 30px rgba(0, 178, 255, 0.4); --font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; --font-size-base: 1rem; --font-size-xl: 1.25rem; --font-size-2xl: 1.5rem; --z-header: 50; --transition-fast: 150ms ease-in-out; --transition-normal: 300ms ease-in-out;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { font-family: var(--font-family); font-size: var(--font-size-base); line-height: 1.6; color: var(--text-primary); background-color: var(--bg-primary); }
        img { max-width: 100%; height: auto; display: block; }
        button { font-family: inherit; border: none; background: none; cursor: pointer; }
        a { color: inherit; text-decoration: none; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 var(--space-lg); }
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: var(--space-sm); padding: var(--space-md) var(--space-xl); font-weight: 600; border-radius: var(--radius-lg); transition: all var(--transition-fast); text-align: center; border: 2px solid transparent; }
        .btn-primary { background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%); color: var(--text-primary); box-shadow: var(--shadow-glow); }
        .btn-primary:hover { transform: translateY(-3px); }
        .btn-outline { background: transparent; color: var(--color-primary); border: 2px solid var(--color-primary); }
        .btn-outline:hover { background: var(--color-primary); color: var(--text-primary); }
        .header { position: sticky; top: 0; left: 0; right: 0; background: rgba(16, 24, 40, 0.95); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255, 255, 255, 0.1); z-index: var(--z-header); }
        .header-container { display: flex; align-items: center; justify-content: space-between; padding: var(--space-lg) 0; min-height: 80px; }
        .logo { display: flex; align-items: center; gap: var(--space-xs); font-size: var(--font-size-2xl); font-weight: 800; }
        .logo-text { color: var(--color-primary); }
        .logo-subtext { color: var(--text-secondary); font-weight: 500; font-size: var(--font-size-base); }
        .header-actions { display: flex; align-items: center; gap: var(--space-lg); }
        .footer { background: var(--color-black); padding: var(--space-4xl) 0 var(--space-xl); border-top: 1px solid rgba(255, 255, 255, 0.1); margin-top: var(--space-4xl); }
        .footer-bottom { border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: var(--space-lg); text-align: center; color: var(--text-muted); font-size: 0.875rem; }
        
        .cart-section { padding: var(--space-4xl) 0; }
        .cart-grid { display: grid; grid-template-columns: 2.5fr 1fr; gap: var(--space-2xl); align-items: flex-start; }
        .cart-items-card, .cart-summary-card { background: var(--bg-secondary); border-radius: var(--radius-xl); padding: var(--space-xl); }
        .cart-table { width: 100%; border-collapse: collapse; }
        .cart-table th, .cart-table td { text-align: left; padding: var(--space-lg) var(--space-md); border-bottom: 1px solid var(--color-gray-700); vertical-align: middle; }
        .cart-table th { color: var(--text-secondary); font-weight: 500; }
        .product-info { display: flex; align-items: center; gap: var(--space-lg); }
        .product-info img { width: 80px; height: 80px; object-fit: cover; border-radius: var(--radius-md); }
        .quantity-input { width: 60px; background: var(--color-gray-700); border: 1px solid var(--color-gray-600); border-radius: var(--radius-sm); color: var(--text-primary); padding: var(--space-sm); text-align: center; font-size: 1rem; }
        .remove-btn { color: var(--text-muted); font-size: var(--font-size-xl); transition: color var(--transition-fast); }
        .remove-btn:hover { color: #ff4d4d; }
        .cart-summary-card h2 { margin-bottom: var(--space-xl); }
        .summary-row { display: flex; justify-content: space-between; margin-bottom: var(--space-lg); font-size: var(--font-size-base); }
        .summary-total { font-size: var(--font-size-xl); font-weight: 700; color: var(--color-primary); border-top: 1px solid var(--color-gray-700); padding-top: var(--space-lg); }
        .empty-cart { text-align: center; padding: var(--space-4xl); color: var(--text-secondary); }
        .empty-cart i { font-size: 4rem; margin-bottom: var(--space-lg); color: var(--text-muted); }
        
        @media (max-width: 768px) {
            .cart-grid { grid-template-columns: 1fr; }
            .cart-table { font-size: 0.875rem; }
            .product-info { flex-direction: column; text-align: center; }
            .product-info img { width: 60px; height: 60px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-container">
                <a href="index.html" class="logo">
                    <span class="logo-text">MX3</span>
                    <span class="logo-subtext">NETWORK</span>
                </a>
                
                <div class="header-actions">
                    <a href="minha-conta.php" class="btn btn-outline">
                        <i class="fas fa-user"></i>
                        Minha Conta
                    </a>
                </div>
            </div>
        </div>
    </header>

    <section class="cart-section">
        <div class="container">
            <h1 style="margin-bottom: var(--space-2xl); font-size: 2.5rem; text-align: center;">Meu Carrinho</h1>
            
            <div id="cart-content">
                <!-- Conteúdo será carregado via JavaScript -->
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; 2025 MX3 Network. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadCart();
        });

        function getCart() {
            return JSON.parse(localStorage.getItem('mx3-cart')) || [];
        }

        function saveCart(cart) {
            localStorage.setItem('mx3-cart', JSON.stringify(cart));
        }

        function loadCart() {
            const cart = getCart();
            const cartContent = document.getElementById('cart-content');

            if (cart.length === 0) {
                cartContent.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <h2>Seu carrinho está vazio</h2>
                        <p>Adicione produtos para continuar com a compra</p>
                        <a href="index.html" class="btn btn-primary" style="margin-top: var(--space-lg);">
                            Continuar Comprando
                        </a>
                    </div>
                `;
                return;
            }

            let cartHTML = `
                <div class="cart-grid">
                    <div class="cart-items-card">
                        <h2 style="margin-bottom: var(--space-xl);">Itens do Carrinho</h2>
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Preço</th>
                                    <th>Quantidade</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
            `;

            let subtotal = 0;

            cart.forEach((item, index) => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;

                cartHTML += `
                    <tr>
                        <td>
                            <div class="product-info">
                                <img src="${item.image}" alt="${item.name}">
                                <div>
                                    <h4>${item.name}</h4>
                                </div>
                            </div>
                        </td>
                        <td>R$ ${item.price.toFixed(2).replace('.', ',')}</td>
                        <td>
                            <input type="number" class="quantity-input" value="${item.quantity}" 
                                   min="1" onchange="updateQuantity(${index}, this.value)">
                        </td>
                        <td>R$ ${itemTotal.toFixed(2).replace('.', ',')}</td>
                        <td>
                            <button class="remove-btn" onclick="removeItem(${index})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });

            const shipping = 0; // Frete grátis
            const total = subtotal + shipping;

            cartHTML += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="cart-summary-card">
                        <h2>Resumo do Pedido</h2>
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span>R$ ${subtotal.toFixed(2).replace('.', ',')}</span>
                        </div>
                        <div class="summary-row">
                            <span>Frete:</span>
                            <span>Grátis</span>
                        </div>
                        <div class="summary-row summary-total">
                            <span>Total:</span>
                            <span>R$ ${total.toFixed(2).replace('.', ',')}</span>
                        </div>
                        
                        <button class="btn btn-primary" style="width: 100%; margin-top: var(--space-lg);" onclick="proceedToCheckout()">
                            Finalizar Compra
                        </button>
                        
                        <a href="index.html" class="btn btn-outline" style="width: 100%; margin-top: var(--space-md);">
                            Continuar Comprando
                        </a>
                    </div>
                </div>
            `;

            cartContent.innerHTML = cartHTML;
        }

        function updateQuantity(index, newQuantity) {
            const cart = getCart();
            if (newQuantity > 0) {
                cart[index].quantity = parseInt(newQuantity);
                saveCart(cart);
                loadCart();
            }
        }

        function removeItem(index) {
            const cart = getCart();
            cart.splice(index, 1);
            saveCart(cart);
            loadCart();
        }

        function proceedToCheckout() {
            const cart = getCart();
            if (cart.length === 0) {
                alert('Seu carrinho está vazio!');
                return;
            }
            
            // Redireciona para a página de finalização
            window.location.href = 'finalizar-compra.php';
        }
    </script>
</body>
</html>

