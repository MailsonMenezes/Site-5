<?php
/**
 * Configuração do Mercado Pago
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Acesse https://www.mercadopago.com.br/developers/
 * 2. Crie uma aplicação
 * 3. Obtenha suas credenciais (Access Token e Public Key)
 * 4. Substitua as variáveis abaixo pelas suas credenciais reais
 * 5. Instale o SDK do Mercado Pago via Composer: composer require mercadopago/dx-php
 */

// CREDENCIAIS DO MERCADO PAGO - SUBSTITUA AQUI
define('MERCADOPAGO_ACCESS_TOKEN', 'SEU_ACCESS_TOKEN_AQUI');
define('MERCADOPAGO_PUBLIC_KEY', 'SEU_PUBLIC_KEY_AQUI');

// URLs de callback
define('MERCADOPAGO_SUCCESS_URL', 'https://seusite.com/pagamento-sucesso.php');
define('MERCADOPAGO_FAILURE_URL', 'https://seusite.com/pagamento-erro.php');
define('MERCADOPAGO_PENDING_URL', 'https://seusite.com/pagamento-pendente.php');
define('MERCADOPAGO_NOTIFICATION_URL', 'https://seusite.com/mercadopago_callback.php');

// Configurações do ambiente
define('MERCADOPAGO_SANDBOX', true); // true para testes, false para produção

/**
 * Função para criar preferência de pagamento
 */
function criarPreferenciaMercadoPago($pedido_id, $pedido_numero, $total, $metodo_pagamento, $dados_cliente) {
    try {
        // Incluir SDK do Mercado Pago
        // require_once 'vendor/autoload.php';
        
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        MercadoPago\SDK::setAccessToken(MERCADOPAGO_ACCESS_TOKEN);
        
        $preference = new MercadoPago\Preference();
        
        // Criar item
        $item = new MercadoPago\Item();
        $item->title = "Pedido MX3 Network #" . $pedido_numero;
        $item->quantity = 1;
        $item->unit_price = floatval($total);
        $item->currency_id = "BRL";
        
        $preference->items = array($item);
        
        // Configurar URLs de retorno
        $preference->back_urls = array(
            "success" => MERCADOPAGO_SUCCESS_URL,
            "failure" => MERCADOPAGO_FAILURE_URL,
            "pending" => MERCADOPAGO_PENDING_URL
        );
        
        $preference->auto_return = "approved";
        $preference->external_reference = $pedido_numero;
        $preference->notification_url = MERCADOPAGO_NOTIFICATION_URL;
        
        // Configurar dados do pagador
        $payer = new MercadoPago\Payer();
        $payer->name = $dados_cliente['nome'];
        $payer->email = $dados_cliente['email'];
        $payer->phone = array(
            "area_code" => substr(preg_replace('/\D/', '', $dados_cliente['telefone']), 0, 2),
            "number" => substr(preg_replace('/\D/', '', $dados_cliente['telefone']), 2)
        );
        
        $preference->payer = $payer;
        
        // Configurar método de pagamento
        if ($metodo_pagamento === 'pix') {
            $preference->payment_methods = array(
                "excluded_payment_methods" => array(),
                "excluded_payment_types" => array(
                    array("id" => "credit_card"),
                    array("id" => "debit_card"),
                    array("id" => "ticket")
                ),
                "installments" => 1
            );
        } elseif ($metodo_pagamento === 'credit_card') {
            $preference->payment_methods = array(
                "excluded_payment_methods" => array(),
                "excluded_payment_types" => array(
                    array("id" => "ticket")
                ),
                "installments" => 12
            );
        } elseif ($metodo_pagamento === 'boleto') {
            $preference->payment_methods = array(
                "excluded_payment_methods" => array(),
                "excluded_payment_types" => array(
                    array("id" => "credit_card"),
                    array("id" => "debit_card")
                ),
                "installments" => 1
            );
        }
        
        $preference->save();
        
        // Retornar URL de pagamento
        if (MERCADOPAGO_SANDBOX) {
            return $preference->sandbox_init_point;
        } else {
            return $preference->init_point;
        }
        */
        
        // REMOVER ESTA LINHA QUANDO CONFIGURAR O SDK:
        return null;
        
    } catch (Exception $e) {
        error_log("Erro no Mercado Pago: " . $e->getMessage());
        return null;
    }
}

/**
 * Função para processar notificação do Mercado Pago
 */
function processarNotificacaoMercadoPago($notification_data) {
    try {
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        MercadoPago\SDK::setAccessToken(MERCADOPAGO_ACCESS_TOKEN);
        
        if ($notification_data['type'] === 'payment') {
            $payment = MercadoPago\Payment::find_by_id($notification_data['data']['id']);
            
            $status_map = [
                'approved' => 'pago',
                'pending' => 'pendente',
                'rejected' => 'cancelado',
                'cancelled' => 'cancelado'
            ];
            
            $novo_status = $status_map[$payment->status] ?? 'pendente';
            
            // Atualizar status do pedido no banco
            global $pdo;
            $sql = "UPDATE pedidos SET status = ?, transaction_id = ? WHERE numero_pedido = ?";
            executeQuery($sql, [$novo_status, $payment->id, $payment->external_reference]);
            
            return true;
        }
        */
        
        return false;
        
    } catch (Exception $e) {
        error_log("Erro ao processar notificação Mercado Pago: " . $e->getMessage());
        return false;
    }
}
?>

