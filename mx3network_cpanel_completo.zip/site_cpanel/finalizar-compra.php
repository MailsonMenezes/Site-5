<?php
session_start();
require_once "db_connect.php";

// Verificar se o usuário está logado (simulação para teste)
if (!isset($_SESSION["loggedin"])) {
    $_SESSION["loggedin"] = true;
    $_SESSION["id"] = 1;
    $_SESSION["nome"] = "Usuário Teste";
    $_SESSION["email"] = "teste@exemplo.com";
    $_SESSION["telefone"] = "(83) 99999-9999";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Finalizar Compra - MX3 Network</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <style>
        :root {
            --color-black: hsl(210, 15%, 5%); --color-gray-900: hsl(210, 15%, 8%); --color-gray-800: hsl(210, 15%, 12%); --color-gray-700: hsl(210, 15%, 16%); --color-gray-600: hsl(210, 15%, 24%); --color-gray-500: hsl(210, 15%, 32%); --color-gray-400: hsl(210, 15%, 48%); --color-gray-300: hsl(210, 15%, 64%); --color-gray-200: hsl(210, 15%, 80%); --color-gray-100: hsl(210, 15%, 96%); --color-white: hsl(0, 0%, 100%); --color-blue-700: hsl(196, 100%, 30%); --color-blue-600: hsl(196, 100%, 40%); --color-blue-500: hsl(196, 100%, 50%); --color-blue-400: hsl(196, 100%, 60%); --color-blue-300: hsl(196, 100%, 70%); --color-primary: var(--color-blue-500); --color-primary-hover: var(--color-blue-400); --color-primary-dark: var(--color-blue-600); --bg-primary: var(--color-gray-900); --bg-secondary: var(--color-gray-800); --bg-tertiary: var(--color-gray-700); --bg-card: rgba(255, 255, 255, 0.05); --bg-card-hover: rgba(255, 255, 255, 0.08); --text-primary: var(--color-white); --text-secondary: var(--color-gray-200); --text-muted: var(--color-gray-400); --space-xs: 0.25rem; --space-sm: 0.5rem; --space-md: 1rem; --space-lg: 1.5rem; --space-xl: 2rem; --space-2xl: 3rem; --space-3xl: 4rem; --space-4xl: 6rem; --radius-sm: 0.375rem; --radius-md: 0.5rem; --radius-lg: 0.75rem; --radius-xl: 1rem; --radius-2xl: 1.5rem; --shadow-glow: 0 0 30px rgba(0, 178, 255, 0.4); --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.4); --font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; --font-size-sm: 0.875rem; --font-size-base: 1rem; --font-size-lg: 1.125rem; --font-size-xl: 1.25rem; --font-size-2xl: 1.5rem; --font-size-3xl: 1.875rem; --font-size-4xl: 2.25rem; --z-header: 50; --transition-fast: 150ms ease-in-out; --transition-normal: 300ms ease-in-out;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { font-family: var(--font-family); font-size: var(--font-size-base); line-height: 1.6; color: var(--text-primary); background-color: var(--bg-primary); }
        img { max-width: 100%; height: auto; display: block; }
        button { font-family: inherit; border: none; background: none; cursor: pointer; }
        a { color: inherit; text-decoration: none; }
        input, select, textarea { font-family: inherit; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 var(--space-lg); }
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: var(--space-sm); padding: var(--space-md) var(--space-xl); font-weight: 600; border-radius: var(--radius-lg); transition: all var(--transition-fast); text-align: center; border: 2px solid transparent; cursor: pointer; }
        .btn-primary { background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%); color: var(--text-primary); box-shadow: var(--shadow-glow); }
        .btn-primary:hover { transform: translateY(-3px); }
        .btn-outline { background: transparent; color: var(--color-primary); border: 2px solid var(--color-primary); }
        .btn-outline:hover { background: var(--color-primary); color: var(--text-primary); }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .header { position: sticky; top: 0; left: 0; right: 0; background: rgba(16, 24, 40, 0.95); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255, 255, 255, 0.1); z-index: var(--z-header); }
        .header-container { display: flex; align-items: center; justify-content: space-between; padding: var(--space-lg) 0; min-height: 80px; }
        .logo { display: flex; align-items: center; gap: var(--space-xs); font-size: var(--font-size-2xl); font-weight: 800; }
        .logo-text { color: var(--color-primary); }
        .logo-subtext { color: var(--text-secondary); font-weight: 500; font-size: var(--font-size-base); }
        .header-actions { display: flex; align-items: center; gap: var(--space-lg); }
        .footer { background: var(--color-black); padding: var(--space-4xl) 0 var(--space-xl); border-top: 1px solid rgba(255, 255, 255, 0.1); margin-top: var(--space-4xl); }
        .footer-bottom { border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: var(--space-lg); text-align: center; color: var(--text-muted); font-size: var(--font-size-sm); }
        
        .checkout-section { padding: var(--space-4xl) 0; }
        .checkout-grid { display: grid; grid-template-columns: 1.8fr 1fr; gap: var(--space-3xl); align-items: flex-start; }
        .checkout-card { background: var(--bg-secondary); border-radius: var(--radius-xl); padding: var(--space-2xl); margin-bottom: var(--space-xl); }
        .checkout-card h2 { font-size: var(--font-size-2xl); font-weight: 700; margin-bottom: var(--space-xl); color: var(--text-primary); display: flex; align-items: center; gap: var(--space-md); }
        .checkout-card h3 { font-size: var(--font-size-xl); font-weight: 600; margin-bottom: var(--space-lg); color: var(--text-primary); }
        .form-group { margin-bottom: var(--space-lg); }
        .form-label { display: block; margin-bottom: var(--space-sm); font-weight: 500; color: var(--text-secondary); }
        .form-input, .form-select { width: 100%; padding: var(--space-md); background: var(--color-gray-700); border: 1px solid var(--color-gray-600); border-radius: var(--radius-md); color: var(--text-primary); font-size: var(--font-size-base); transition: border-color var(--transition-fast); }
        .form-input:focus, .form-select:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(0, 178, 255, 0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-lg); }
        .form-row-3 { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: var(--space-lg); }
        
        .payment-methods { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-xl); }
        .payment-method { background: var(--color-gray-700); border: 2px solid var(--color-gray-600); border-radius: var(--radius-lg); padding: var(--space-lg); text-align: center; cursor: pointer; transition: all var(--transition-fast); position: relative; }
        .payment-method:hover { border-color: var(--color-primary); background: var(--color-gray-600); }
        .payment-method.selected { border-color: var(--color-primary); background: var(--color-gray-600); box-shadow: 0 0 20px rgba(0, 178, 255, 0.3); }
        .payment-method input[type="radio"] { position: absolute; opacity: 0; }
        .payment-method-icon { font-size: var(--font-size-3xl); margin-bottom: var(--space-sm); color: var(--color-primary); }
        .payment-method-name { font-weight: 600; color: var(--text-primary); }
        .payment-method-desc { font-size: var(--font-size-sm); color: var(--text-muted); margin-top: var(--space-xs); }
        
        .payment-platforms { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-md); margin-bottom: var(--space-xl); }
        .payment-platform { background: var(--color-gray-700); border: 2px solid var(--color-gray-600); border-radius: var(--radius-lg); padding: var(--space-md); text-align: center; cursor: pointer; transition: all var(--transition-fast); position: relative; }
        .payment-platform:hover { border-color: var(--color-primary); background: var(--color-gray-600); }
        .payment-platform.selected { border-color: var(--color-primary); background: var(--color-gray-600); box-shadow: 0 0 20px rgba(0, 178, 255, 0.3); }
        .payment-platform input[type="radio"] { position: absolute; opacity: 0; }
        .payment-platform-name { font-weight: 600; color: var(--text-primary); font-size: var(--font-size-sm); }
        
        .order-summary { background: var(--bg-secondary); border-radius: var(--radius-xl); padding: var(--space-2xl); position: sticky; top: 100px; }
        .order-summary h2 { font-size: var(--font-size-2xl); font-weight: 700; margin-bottom: var(--space-xl); color: var(--text-primary); }
        .order-item { display: flex; gap: var(--space-md); margin-bottom: var(--space-lg); padding-bottom: var(--space-lg); border-bottom: 1px solid var(--color-gray-700); }
        .order-item:last-child { margin-bottom: 0; border-bottom: none; }
        .order-item img { width: 60px; height: 60px; object-fit: cover; border-radius: var(--radius-md); }
        .order-item-info h4 { font-weight: 600; color: var(--text-primary); margin-bottom: var(--space-xs); }
        .order-item-info p { font-size: var(--font-size-sm); color: var(--text-muted); }
        .order-item-price { font-weight: 600; color: var(--color-primary); margin-left: auto; }
        .order-totals { margin-top: var(--space-xl); padding-top: var(--space-xl); border-top: 1px solid var(--color-gray-600); }
        .total-row { display: flex; justify-content: space-between; margin-bottom: var(--space-md); }
        .total-row.final { font-size: var(--font-size-xl); font-weight: 700; margin-top: var(--space-lg); padding-top: var(--space-lg); border-top: 1px solid var(--color-gray-600); color: var(--color-primary); }
        
        @media (max-width: 768px) {
            .checkout-grid { grid-template-columns: 1fr; }
            .form-row, .form-row-3 { grid-template-columns: 1fr; }
            .payment-methods { grid-template-columns: 1fr; }
            .payment-platforms { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-container">
                <a href="index.html" class="logo">
                    <span class="logo-text">MX3</span>
                    <span class="logo-subtext">NETWORK</span>
                </a>
                
                <div class="header-actions">
                    <a href="carrinho.php" class="btn btn-outline">
                        <i class="fas fa-arrow-left"></i>
                        Voltar ao Carrinho
                    </a>
                </div>
            </div>
        </div>
    </header>

    <section class="checkout-section">
        <div class="container">
            <h1 style="margin-bottom: var(--space-2xl); font-size: 2.5rem; text-align: center;">Finalizar Compra</h1>
            
            <form id="checkout-form" class="checkout-grid">
                <div class="checkout-forms">
                    <!-- Dados de Entrega -->
                    <div class="checkout-card">
                        <h2><i class="fas fa-truck"></i> Dados de Entrega</h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Nome Completo</label>
                                <input type="text" class="form-input" name="nome" value="<?php echo $_SESSION['nome']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">E-mail</label>
                                <input type="email" class="form-input" name="email" value="<?php echo $_SESSION['email']; ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Telefone</label>
                                <input type="tel" class="form-input" name="telefone" value="<?php echo $_SESSION['telefone']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">CPF/CNPJ</label>
                                <input type="text" class="form-input" name="documento" required>
                            </div>
                        </div>
                        
                        <div class="form-row-3">
                            <div class="form-group">
                                <label class="form-label">CEP</label>
                                <input type="text" class="form-input" name="cep" id="cep" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Estado</label>
                                <select class="form-select" name="estado" id="estado" required>
                                    <option value="">Selecione</option>
                                    <option value="PB">Paraíba</option>
                                    <option value="PE">Pernambuco</option>
                                    <option value="RN">Rio Grande do Norte</option>
                                    <option value="CE">Ceará</option>
                                    <option value="AL">Alagoas</option>
                                    <option value="SE">Sergipe</option>
                                    <option value="BA">Bahia</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Cidade</label>
                                <input type="text" class="form-input" name="cidade" id="cidade" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Endereço</label>
                                <input type="text" class="form-input" name="endereco" id="endereco" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Número</label>
                                <input type="text" class="form-input" name="numero" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Complemento</label>
                                <input type="text" class="form-input" name="complemento">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Bairro</label>
                                <input type="text" class="form-input" name="bairro" id="bairro" required>
                            </div>
                        </div>
                    </div>

                    <!-- Forma de Pagamento -->
                    <div class="checkout-card">
                        <h2><i class="fas fa-credit-card"></i> Forma de Pagamento</h2>
                        
                        <div class="payment-methods">
                            <label class="payment-method">
                                <input type="radio" name="payment_method" value="pix" checked>
                                <div class="payment-method-icon"><i class="fas fa-qrcode"></i></div>
                                <div class="payment-method-name">PIX</div>
                                <div class="payment-method-desc">Aprovação instantânea</div>
                            </label>
                            
                            <label class="payment-method">
                                <input type="radio" name="payment_method" value="credit_card">
                                <div class="payment-method-icon"><i class="fas fa-credit-card"></i></div>
                                <div class="payment-method-name">Cartão de Crédito</div>
                                <div class="payment-method-desc">Parcelamento disponível</div>
                            </label>
                            
                            <label class="payment-method">
                                <input type="radio" name="payment_method" value="boleto">
                                <div class="payment-method-icon"><i class="fas fa-barcode"></i></div>
                                <div class="payment-method-name">Boleto</div>
                                <div class="payment-method-desc">Vencimento em 3 dias</div>
                            </label>
                        </div>
                        
                        <h3>Plataforma de Pagamento</h3>
                        <div class="payment-platforms">
                            <label class="payment-platform">
                                <input type="radio" name="payment_platform" value="mercadopago" checked>
                                <div class="payment-platform-name">Mercado Pago</div>
                            </label>
                            
                            <label class="payment-platform">
                                <input type="radio" name="payment_platform" value="pagseguro">
                                <div class="payment-platform-name">PagSeguro</div>
                            </label>
                            
                            <label class="payment-platform">
                                <input type="radio" name="payment_platform" value="paypal">
                                <div class="payment-platform-name">PayPal</div>
                            </label>
                            
                            <label class="payment-platform">
                                <input type="radio" name="payment_platform" value="infinitepay">
                                <div class="payment-platform-name">InfinitePay</div>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Resumo do Pedido -->
                <div class="order-summary">
                    <h2>Resumo do Pedido</h2>
                    <div id="order-items">
                        <!-- Itens serão carregados via JavaScript -->
                    </div>
                    
                    <div class="order-totals">
                        <div class="total-row">
                            <span>Subtotal:</span>
                            <span id="subtotal">R$ 0,00</span>
                        </div>
                        <div class="total-row">
                            <span>Frete:</span>
                            <span id="shipping">Grátis</span>
                        </div>
                        <div class="total-row final">
                            <span>Total:</span>
                            <span id="total">R$ 0,00</span>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: var(--space-xl);">
                        <i class="fas fa-lock"></i>
                        Finalizar Pedido
                    </button>
                </div>
            </form>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; 2025 MX3 Network. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadOrderSummary();
            setupPaymentMethods();
            setupCEPLookup();
        });

        function getCart() {
            return JSON.parse(localStorage.getItem('mx3-cart')) || [];
        }

        function loadOrderSummary() {
            const cart = getCart();
            const orderItems = document.getElementById('order-items');
            
            if (cart.length === 0) {
                window.location.href = 'carrinho.php';
                return;
            }

            let subtotal = 0;
            let itemsHTML = '';

            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;

                itemsHTML += `
                    <div class="order-item">
                        <img src="${item.image}" alt="${item.name}">
                        <div class="order-item-info">
                            <h4>${item.name}</h4>
                            <p>Quantidade: ${item.quantity}</p>
                        </div>
                        <div class="order-item-price">R$ ${itemTotal.toFixed(2).replace('.', ',')}</div>
                    </div>
                `;
            });

            orderItems.innerHTML = itemsHTML;
            document.getElementById('subtotal').textContent = `R$ ${subtotal.toFixed(2).replace('.', ',')}`;
            document.getElementById('total').textContent = `R$ ${subtotal.toFixed(2).replace('.', ',')}`;
        }

        function setupPaymentMethods() {
            const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
            const paymentPlatforms = document.querySelectorAll('input[name="payment_platform"]');

            paymentMethods.forEach(method => {
                method.addEventListener('change', function() {
                    document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
                    this.closest('.payment-method').classList.add('selected');
                });
            });

            paymentPlatforms.forEach(platform => {
                platform.addEventListener('change', function() {
                    document.querySelectorAll('.payment-platform').forEach(el => el.classList.remove('selected'));
                    this.closest('.payment-platform').classList.add('selected');
                });
            });

            // Selecionar o primeiro método por padrão
            document.querySelector('.payment-method').classList.add('selected');
            document.querySelector('.payment-platform').classList.add('selected');
        }

        function setupCEPLookup() {
            const cepInput = document.getElementById('cep');
            
            cepInput.addEventListener('blur', function() {
                const cep = this.value.replace(/\D/g, '');
                
                if (cep.length === 8) {
                    fetch(`https://viacep.com.br/ws/${cep}/json/`)
                        .then(response => response.json())
                        .then(data => {
                            if (!data.erro) {
                                document.getElementById('endereco').value = data.logradouro;
                                document.getElementById('bairro').value = data.bairro;
                                document.getElementById('cidade').value = data.localidade;
                                document.getElementById('estado').value = data.uf;
                            }
                        })
                        .catch(error => console.log('Erro ao buscar CEP:', error));
                }
            });
        }

        document.getElementById('checkout-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const cart = getCart();
            
            // Adicionar itens do carrinho ao formulário
            formData.append('cart_items', JSON.stringify(cart));
            
            // Enviar para processamento
            fetch('processa_compra.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Limpar carrinho
                    localStorage.removeItem('mx3-cart');
                    
                    // Redirecionar para página de pagamento ou confirmação
                    if (data.payment_url) {
                        window.location.href = data.payment_url;
                    } else {
                        alert('Pedido realizado com sucesso! Você receberá as instruções de pagamento por e-mail.');
                        window.location.href = 'index.html';
                    }
                } else {
                    alert('Erro ao processar pedido: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                alert('Erro ao processar pedido. Tente novamente.');
            });
        });
    </script>
</body>
</html>

