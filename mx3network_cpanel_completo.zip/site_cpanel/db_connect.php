<?php
/**
 * Configuração de Conexão com Banco de Dados
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Substitua as variáveis abaixo pelos dados do seu banco MySQL no cPanel
 * 2. Crie um banco de dados MySQL através do cPanel
 * 3. Execute o script SQL fornecido para criar as tabelas necessárias
 */

// CONFIGURAÇÕES DO BANCO DE DADOS - ALTERE AQUI
$db_host = 'localhost';                    // Geralmente 'localhost' no cPanel
$db_name = 'SEU_BANCO_DE_DADOS';          // Nome do banco criado no cPanel
$db_user = 'SEU_USUARIO_MYSQL';           // Usuário MySQL do cPanel
$db_pass = 'SUA_SENHA_MYSQL';             // Senha MySQL do cPanel

// Configurações de charset e timezone
$db_charset = 'utf8mb4';
date_default_timezone_set('America/Sao_Paulo');

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=$db_charset",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log("Erro de conexão com banco de dados: " . $e->getMessage());
    die("Erro de conexão com banco de dados. Verifique as configurações.");
}

/**
 * Função para executar queries de forma segura
 */
function executeQuery($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Erro na query: " . $e->getMessage());
        return false;
    }
}

/**
 * Função para buscar um registro
 */
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt ? $stmt->fetch() : false;
}

/**
 * Função para buscar múltiplos registros
 */
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt ? $stmt->fetchAll() : false;
}

/**
 * Função para inserir dados e retornar o ID
 */
function insertAndGetId($sql, $params = []) {
    global $pdo;
    $stmt = executeQuery($sql, $params);
    return $stmt ? $pdo->lastInsertId() : false;
}
?>

