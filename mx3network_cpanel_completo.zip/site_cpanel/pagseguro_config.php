<?php
/**
 * Configuração do PagSeguro
 * 
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 1. Acesse https://dev.pagseguro.uol.com.br/
 * 2. Crie uma conta de desenvolvedor
 * 3. Obtenha suas credenciais (Token e App ID)
 * 4. Substitua as variáveis abaixo pelas suas credenciais reais
 * 5. Instale o SDK do PagSeguro via Composer: composer require pagseguro/pagseguro-php-sdk
 */

// CREDENCIAIS DO PAGSEGURO - SUBSTITUA AQUI
define('PAGSEGURO_TOKEN', 'SEU_TOKEN_AQUI');
define('PAGSEGURO_APP_ID', 'SEU_APP_ID_AQUI');
define('PAGSEGURO_APP_KEY', 'SEU_APP_KEY_AQUI');

// URLs de callback
define('PAGSEGURO_NOTIFICATION_URL', 'https://seusite.com/pagseguro_callback.php');
define('PAGSEGURO_REDIRECT_URL', 'https://seusite.com/pagamento-sucesso.php');

// Configurações do ambiente
define('PAGSEGURO_SANDBOX', true); // true para testes, false para produção

/**
 * Função para criar sessão de pagamento PagSeguro
 */
function criarPagamentoPagSeguro($pedido_id, $pedido_numero, $total, $metodo_pagamento, $dados_cliente) {
    try {
        // Incluir SDK do PagSeguro
        // require_once 'vendor/autoload.php';
        
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        \PagSeguro\Configuration\Configure::setEnvironment(PAGSEGURO_SANDBOX ? 'sandbox' : 'production');
        \PagSeguro\Configuration\Configure::setAccountCredentials(PAGSEGURO_TOKEN, PAGSEGURO_APP_ID, PAGSEGURO_APP_KEY);
        \PagSeguro\Configuration\Configure::setCharset('UTF-8');
        \PagSeguro\Configuration\Configure::setLog(true, '/tmp/pagseguro.log');
        
        $payment = new \PagSeguro\Domains\Requests\Payment();
        
        $payment->addItem()->withParameters(
            '001',
            'Pedido MX3 Network #' . $pedido_numero,
            1,
            $total
        );
        
        $payment->setCurrency("BRL");
        $payment->setReference($pedido_numero);
        $payment->setRedirectUrl(PAGSEGURO_REDIRECT_URL);
        $payment->addParameter('notificationURL', PAGSEGURO_NOTIFICATION_URL);
        
        // Configurar dados do comprador
        $payment->setSender()->setName($dados_cliente['nome']);
        $payment->setSender()->setEmail($dados_cliente['email']);
        
        $phone = preg_replace('/\D/', '', $dados_cliente['telefone']);
        $payment->setSender()->setPhone()->withParameters(
            substr($phone, 0, 2),
            substr($phone, 2)
        );
        
        $payment->setSender()->setDocument()->withParameters(
            'CPF',
            preg_replace('/\D/', '', $dados_cliente['documento'])
        );
        
        // Configurar endereço
        $payment->setShipping()->setAddress()->withParameters(
            $dados_cliente['endereco'],
            $dados_cliente['numero'],
            $dados_cliente['bairro'],
            $dados_cliente['cep'],
            $dados_cliente['cidade'],
            $dados_cliente['estado'],
            'BRA',
            $dados_cliente['complemento']
        );
        
        // Configurar método de pagamento
        if ($metodo_pagamento === 'credit_card') {
            $payment->setPaymentMethod()->setType('CREDITCARD');
        } elseif ($metodo_pagamento === 'boleto') {
            $payment->setPaymentMethod()->setType('BOLETO');
        } elseif ($metodo_pagamento === 'pix') {
            $payment->setPaymentMethod()->setType('PIX');
        }
        
        $result = $payment->register(\PagSeguro\Configuration\Configure::getAccountCredentials());
        
        return $result->getRedirectUrl();
        */
        
        // REMOVER ESTA LINHA QUANDO CONFIGURAR O SDK:
        return null;
        
    } catch (Exception $e) {
        error_log("Erro no PagSeguro: " . $e->getMessage());
        return null;
    }
}

/**
 * Função para processar notificação do PagSeguro
 */
function processarNotificacaoPagSeguro($notification_code) {
    try {
        // DESCOMENTE E CONFIGURE QUANDO TIVER O SDK INSTALADO:
        /*
        \PagSeguro\Configuration\Configure::setEnvironment(PAGSEGURO_SANDBOX ? 'sandbox' : 'production');
        \PagSeguro\Configuration\Configure::setAccountCredentials(PAGSEGURO_TOKEN, PAGSEGURO_APP_ID, PAGSEGURO_APP_KEY);
        
        $transaction = \PagSeguro\Services\Transactions\Notification::check(
            \PagSeguro\Configuration\Configure::getAccountCredentials(),
            $notification_code
        );
        
        $status_map = [
            1 => 'pendente',    // Aguardando pagamento
            2 => 'pendente',    // Em análise
            3 => 'pago',        // Paga
            4 => 'pago',        // Disponível
            5 => 'pendente',    // Em disputa
            6 => 'cancelado',   // Devolvida
            7 => 'cancelado'    // Cancelada
        ];
        
        $novo_status = $status_map[$transaction->getStatus()] ?? 'pendente';
        
        // Atualizar status do pedido no banco
        global $pdo;
        $sql = "UPDATE pedidos SET status = ?, transaction_id = ? WHERE numero_pedido = ?";
        executeQuery($sql, [$novo_status, $transaction->getCode(), $transaction->getReference()]);
        
        return true;
        */
        
        return false;
        
    } catch (Exception $e) {
        error_log("Erro ao processar notificação PagSeguro: " . $e->getMessage());
        return false;
    }
}
?>

