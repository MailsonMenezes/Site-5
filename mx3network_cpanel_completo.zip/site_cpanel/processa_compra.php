<?php
session_start();
require_once "db_connect.php";

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método não permitido');
    }

    // Validar dados obrigatórios
    $required_fields = ['nome', 'email', 'telefone', 'documento', 'cep', 'endereco', 'numero', 'bairro', 'cidade', 'estado', 'payment_method', 'payment_platform'];
    
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Campo obrigatório não preenchido: $field");
        }
    }

    // Validar carrinho
    if (empty($_POST['cart_items'])) {
        throw new Exception('Carrinho vazio');
    }

    $cart_items = json_decode($_POST['cart_items'], true);
    if (empty($cart_items)) {
        throw new Exception('Itens do carrinho inválidos');
    }

    // Calcular totais
    $subtotal = 0;
    foreach ($cart_items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    
    $frete = 0; // Frete grátis
    $total = $subtotal + $frete;

    // Gerar número do pedido
    $pedido_numero = 'PED' . date('YmdHis') . rand(100, 999);

    // Inserir pedido no banco de dados
    $sql_pedido = "INSERT INTO pedidos (
        numero_pedido, usuario_id, nome, email, telefone, documento,
        cep, endereco, numero, complemento, bairro, cidade, estado,
        subtotal, frete, total, status, metodo_pagamento, plataforma_pagamento,
        data_criacao
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?, NOW())";

    $pedido_id = insertAndGetId($sql_pedido, [
        $pedido_numero,
        $_SESSION['id'] ?? null,
        $_POST['nome'],
        $_POST['email'],
        $_POST['telefone'],
        $_POST['documento'],
        $_POST['cep'],
        $_POST['endereco'],
        $_POST['numero'],
        $_POST['complemento'] ?? '',
        $_POST['bairro'],
        $_POST['cidade'],
        $_POST['estado'],
        $subtotal,
        $frete,
        $total,
        $_POST['payment_method'],
        $_POST['payment_platform']
    ]);

    if (!$pedido_id) {
        throw new Exception('Erro ao criar pedido');
    }

    // Inserir itens do pedido
    $sql_item = "INSERT INTO pedido_itens (pedido_id, produto_id, nome, preco, quantidade, total) VALUES (?, ?, ?, ?, ?, ?)";
    
    foreach ($cart_items as $item) {
        $item_total = $item['price'] * $item['quantity'];
        executeQuery($sql_item, [
            $pedido_id,
            $item['id'],
            $item['name'],
            $item['price'],
            $item['quantity'],
            $item_total
        ]);
    }

    // Processar pagamento baseado na plataforma selecionada
    $payment_url = null;
    $payment_platform = $_POST['payment_platform'];
    $payment_method = $_POST['payment_method'];

    switch ($payment_platform) {
        case 'mercadopago':
            $payment_url = processarMercadoPago($pedido_id, $pedido_numero, $total, $payment_method, $_POST);
            break;
            
        case 'pagseguro':
            $payment_url = processarPagSeguro($pedido_id, $pedido_numero, $total, $payment_method, $_POST);
            break;
            
        case 'paypal':
            $payment_url = processarPayPal($pedido_id, $pedido_numero, $total, $payment_method, $_POST);
            break;
            
        case 'infinitepay':
            $payment_url = processarInfinitePay($pedido_id, $pedido_numero, $total, $payment_method, $_POST);
            break;
            
        default:
            throw new Exception('Plataforma de pagamento não suportada');
    }

    // Salvar dados do pedido em arquivo JSON para backup
    $pedido_data = [
        'pedido_id' => $pedido_id,
        'numero_pedido' => $pedido_numero,
        'dados_cliente' => $_POST,
        'itens' => $cart_items,
        'totais' => [
            'subtotal' => $subtotal,
            'frete' => $frete,
            'total' => $total
        ],
        'data_criacao' => date('Y-m-d H:i:s')
    ];
    
    file_put_contents("pedido_{$pedido_numero}.json", json_encode($pedido_data, JSON_PRETTY_PRINT));

    echo json_encode([
        'success' => true,
        'pedido_id' => $pedido_id,
        'pedido_numero' => $pedido_numero,
        'payment_url' => $payment_url,
        'message' => 'Pedido criado com sucesso'
    ]);

} catch (Exception $e) {
    error_log("Erro no processamento da compra: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * FUNÇÕES DE PROCESSAMENTO DE PAGAMENTO
 * 
 * IMPORTANTE: Estas funções precisam ser configuradas com as credenciais das APIs
 * Substitua os comentários "CONFIGURAR API" pelas implementações reais
 */

function processarMercadoPago($pedido_id, $pedido_numero, $total, $payment_method, $dados) {
    // CONFIGURAR API DO MERCADO PAGO AQUI
    // Incluir arquivo: require_once "mercadopago_config.php";
    
    // Exemplo de implementação:
    /*
    $mp = new MercadoPago\SDK("SEU_ACCESS_TOKEN");
    
    $preference = new MercadoPago\Preference();
    $item = new MercadoPago\Item();
    $item->title = "Pedido #" . $pedido_numero;
    $item->quantity = 1;
    $item->unit_price = $total;
    
    $preference->items = array($item);
    $preference->external_reference = $pedido_numero;
    $preference->notification_url = "https://seusite.com/mercadopago_callback.php";
    
    $preference->save();
    
    return $preference->init_point;
    */
    
    return null; // Retornar URL de pagamento quando configurado
}

function processarPagSeguro($pedido_id, $pedido_numero, $total, $payment_method, $dados) {
    // CONFIGURAR API DO PAGSEGURO AQUI
    // Incluir arquivo: require_once "pagseguro_config.php";
    
    return null; // Retornar URL de pagamento quando configurado
}

function processarPayPal($pedido_id, $pedido_numero, $total, $payment_method, $dados) {
    // CONFIGURAR API DO PAYPAL AQUI
    // Incluir arquivo: require_once "paypal_config.php";
    
    return null; // Retornar URL de pagamento quando configurado
}

function processarInfinitePay($pedido_id, $pedido_numero, $total, $payment_method, $dados) {
    // CONFIGURAR API DO INFINITEPAY AQUI
    // Incluir arquivo: require_once "infinitepay_config.php";
    
    return null; // Retornar URL de pagamento quando configurado
}
?>

